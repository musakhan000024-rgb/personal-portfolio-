# JaweRia Gul — Personal Web Development Portfolio

This folder contains the complete portfolio website.

Files:
- index.html
- style.css
- script.js
- README.md

Requirements included:
- Home, About Me, Projects and Contact sections
- HTML, CSS and JavaScript
- Responsive/mobile design
- Three project/assignment cards
- JavaScript navigation and contact-form interaction
- Git/GitHub-ready structure
- Ready for static deployment

Before final submission:
1. Replace the placeholder email.
2. Add your real GitHub profile URL.
3. Replace the three project placeholder links with your actual project/repository links. Projects: Interactive To-Do List, Responsive Product Landing Page, and Personal Portfolio Website.
4. Deploy the website and copy the live URL.
5. Push the folder to a GitHub repository.
