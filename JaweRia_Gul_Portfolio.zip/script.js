const menuButton=document.querySelector(".menu-toggle");
const navLinks=document.querySelector(".nav-links");
menuButton.addEventListener("click",()=>{const open=navLinks.classList.toggle("open");menuButton.setAttribute("aria-expanded",open)});
document.querySelectorAll(".nav-links a").forEach(link=>link.addEventListener("click",()=>navLinks.classList.remove("open")));
document.querySelectorAll(".placeholder-link").forEach(link=>link.addEventListener("click",(e)=>{if(link.getAttribute("href")==="#"){e.preventDefault();alert("Please replace this placeholder with your real project or GitHub URL before submission.");}}));
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("contactForm").addEventListener("submit",(e)=>{e.preventDefault();const name=document.getElementById("name").value.trim();const message=document.getElementById("formMessage");message.textContent=`Thank you, ${name}! Your message has been prepared successfully.`;e.target.reset();});